from webapp import app

app.run(port=5000, debug=True)