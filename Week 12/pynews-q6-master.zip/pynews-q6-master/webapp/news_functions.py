import requests     # "Module not found" --> pip install requests

url = "https://newsapi.org/v2/everything"
token = "5719809a4f814d0d9f8cb98e7a3d97de"

def get_news(query):
    params = {
        "apiKey": token,
        "q": "query",
        "from": "2021-03-01"
    }

    results = requests.get(url, params=params)
    return results.json()['articles']