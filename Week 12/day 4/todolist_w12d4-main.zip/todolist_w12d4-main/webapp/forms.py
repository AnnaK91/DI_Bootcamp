import flask_wtf
import wtforms


class AddTodoForm(flask_wtf.FlaskForm):

    details = wtforms.StringField("Todo: ")

    submit  = wtforms.SubmitField("Add a TODO")

