from webapp import app

app.run(debug=True)
