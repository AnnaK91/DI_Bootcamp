import os
import requests
import json

import flask
import flask_sqlalchemy, flask_migrate



app = flask.Flask(__name__)

app.config["SECRET_KEY"] = "thisisaverysecretKEY"


# __file__ is __https://jsonplaceholder.typicode.com/usersinit__.py
# os.path.dirname(path) is the name of the parent directory of the path
# >>> os.path.dirname("__init__") is webapp <<<
# os.path.abspath(path) is the absolute path to path
# >>> os.path.abspath("webapp") is /home/eyal/..../daily_challenge_w12d3/webapp <<<

# --> At the end, basedir is the aboslute path of the app folder

basedir = os.path.abspath(os.path.dirname(__file__)) # import os !

app.config["SQLALCHEMY_DATABASE_URI"] = 'sqlite:///' + os.path.join(basedir, 'app.db')
#app.config["SQLALCHEMY_DATABASE_URI"] = "postgresql://postgres:postgres@localhost:5432/airline"

db = flask_sqlalchemy.SQLAlchemy(app)
migrate = flask_migrate.Migrate(app=app, db=db)

from . import models, routes
##### END OF INITIALISATION #####
