import flask

from . import models, forms
from . import app, db


@app.route("/")
def todo_list():

    todos = models.Todo.query.all()

    return flask.render_template("todo_list.html", todos=todos)


@app.route("/add-todo", methods=["GET","POST"])
def add_todo():
    form = forms.AddTodoForm()

    # Request method is POST
    if flask.request.method == "POST":
        # The form is valid
        if form.validate_on_submit():
            # Do something with the data
            details = form.details.data

            todo = models.Todo(details=details)
            todo.save()

            return flask.redirect("/")

        # The form is invalid
        else:
            print("Something went wrong: ", form.errors)

    # Request method is GET
    return flask.render_template("add_todo.html", form=form)


@app.route("/check/<int:id>")
def check_todo(id):

    # Retrieve the Todo object
    todo = models.Todo.query.get(id)

    # Marking todo.done as True
    todo.done = True

    # Commit our changes to the database
    db.session.commit()

    # Redirecting to home page
    return flask.redirect("/")


