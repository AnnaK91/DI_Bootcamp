#!/usr/bin/python3

##############################################
#
# models.py
# webapp
#
##############################################

from . import db

"""
Checked feature:
    - Add a "done" attribute to the Todo, default is False
    - Create a route /check/<int:id> (id is the id of the todo) that
    mark the Todo as done and redirect to the homepage (/)

    Bonus:
    - Add a button next to each element of the Todo list in the homepage that checks it

"""


class Todo(db.Model):

    id = db.Column(db.Integer(), primary_key=True)

    details = db.Column(db.Text())
    done = db.Column(db.Boolean(), default=False)
    #due_date = db.Column(db.DateTime())

    def save(self):
        db.session.add(self)
        db.session.commit()




